document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (validateLogin(username, password)) {
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('report-container').style.display = 'block';
    } else {
        alert('Invalid username or password.');
    }
});

document.getElementById('faultForm').addEventListener('submit', function(event) {
    event.preventDefault();

    document.getElementById('faultForm').style.display = 'none';
    document.getElementById('confirmation').style.display = 'block';
});

function validateLogin(username, password) {
    // For demonstration purposes, we'll use a hardcoded username and password
    const validUsername = 'staffmember';
    const validPassword = 'letmein!123';

    return username === validUsername && password === validPassword;
}


